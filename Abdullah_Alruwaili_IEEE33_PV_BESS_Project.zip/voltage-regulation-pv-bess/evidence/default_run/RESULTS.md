# Generated simulation summary

Author: Abdullah Alruwaili (prepared project; review pending).

These values were calculated by this run, using synthetic profiles. They are not field measurements. A completed run does not establish that the author personally reviewed or performed it.

| scenario | line_loss_mwh | battery_conversion_loss_mwh | combined_loss_mwh | min_voltage_pu | voltage_violation_bus_hours |
| --- | --- | --- | --- | --- | --- |
| baseline | 2.87256 | 0 | 2.87256 | 0.91309 | 284 |
| pv_only | 2.24483 | 0 | 2.24483 | 0.914919 | 129 |
| pv_bess | 2.07999 | 0.172421 | 2.25241 | 0.920269 | 118 |

Compare PV + BESS against PV alone as well as against baseline. Lower line losses need not mean lower combined losses. Remaining voltage violations must be reported. The 0.95–1.05 pu default is a study target, not a regulatory compliance claim.

See summary.csv for all metrics, validation.json for the nominal check, and manifest.json for provenance.
