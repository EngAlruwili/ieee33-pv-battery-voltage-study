# Preparation evidence

These files record actual runs executed by the assistant while preparing the project for Abdullah Alruwaili. They are **not** proof that Abdullah personally ran, reviewed or completed the study.

- `default_run/`: 72 hourly scenario cases, two nominal benchmark solves, raw CSVs, generated summary, model/solver checks, provenance and seven figure sets.
- `sensitivity_run/`: nine one-factor-at-a-time cases, each with baseline/PV/PV + BESS, saved inputs and hourly output, plus a combined sensitivity table and completion metadata.
- `tests.txt`: output of the eight engineering tests in the final preparation environment.

The simulation code can reproduce these outputs from the configuration and profile files. New work should go in `results/` so that this preparation evidence remains distinguishable from the author's own runs. See `docs/VERIFICATION.md` for interpretation and limitations.
